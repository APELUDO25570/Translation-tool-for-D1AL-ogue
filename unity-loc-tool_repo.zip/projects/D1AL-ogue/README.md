# D1AL-ogue — pt-BR

- Jogo: D1AL-ogue (Steam), Unity 6000.0.61f1, Unity Localization + Addressables.
- Bundle de textos: `localization-string-tables-english(unitedstates)(en-us)_assets_all.bundle`
  (fica em `D1AL-ogue_Data/StreamingAssets/aa/StandaloneWindows64/`). **Não incluímos arquivos do jogo aqui.**
- A tradução substitui o idioma **English** (o jogo não tem um slot de idioma novo).

Os CSVs em `pt-BR/` têm uma linha por texto único do jogo: `source` (inglês), `translation` (preencha), `count`, `note`.
