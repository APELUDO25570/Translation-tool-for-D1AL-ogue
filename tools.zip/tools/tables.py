import struct, json, sys
sys.path.insert(0,'/home/claude')
import ufs, sf

def rd_str(d,p):
    n=struct.unpack_from('<i',d,p)[0]; p+=4
    s=d[p:p+n]; p+=n; p=(p+3)&~3
    return s,p

def parse_table(b):
    p=12+4+12   # GameObject PPtr, Enabled(+pad), Script PPtr
    name,p=rd_str(b,p)
    code,p=rd_str(b,p)
    shared=b[p:p+12]; p+=12
    mcount=struct.unpack_from('<i',b,p)[0]; assert mcount==0,mcount
    p+=4
    head=b[:p]
    n=struct.unpack_from('<i',b,p)[0]; p+=4
    ents=[]
    for _ in range(n):
        id_=struct.unpack_from('<Q',b,p)[0]; p+=8
        s,p=rd_str(b,p)
        mc=struct.unpack_from('<i',b,p)[0]; assert mc==0,(mc,len(ents)); p+=4
        ents.append((id_,s.decode('utf-8')))
    tail=b[p:]
    return name.decode(),head,ents,tail

def build_table(head,ents,tail=b''):
    out=bytearray(head)
    out+=struct.pack('<i',len(ents))
    for id_,s in ents:
        bs=s.encode('utf-8')
        out+=struct.pack('<Q',id_)+struct.pack('<i',len(bs))+bs
        out+=b'\0'*((-len(bs))%4)
        out+=struct.pack('<i',0)
    out+=tail
    return bytes(out)
