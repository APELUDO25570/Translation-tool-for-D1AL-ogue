import struct, sys, lzma

def lz4_block(src, usize):
    dst = bytearray(); i = 0; n = len(src)
    while i < n:
        t = src[i]; i += 1
        l = t >> 4
        if l == 15:
            while True:
                b = src[i]; i += 1; l += b
                if b != 255: break
        dst += src[i:i+l]; i += l
        if i >= n: break
        off = src[i] | (src[i+1] << 8); i += 2
        m = t & 15
        if m == 15:
            while True:
                b = src[i]; i += 1; m += b
                if b != 255: break
        m += 4
        for _ in range(m):
            dst.append(dst[-off])
    return bytes(dst)

def decomp(data, ctype, usize):
    if ctype == 0: return data
    if ctype == 1: return lzma.LZMADecompressor(format=lzma.FORMAT_ALONE).decompress(data) if False else lzma.decompress(data[:5]+struct.pack('<q',usize)+data[5:], format=lzma.FORMAT_ALONE)
    if ctype in (2,3): return lz4_block(data, usize)
    raise Exception('ctype %d'%ctype)

def read_cstr(d, p):
    e = d.index(b'\0', p); return d[p:e].decode(), e+1

def load(path):
    d = open(path,'rb').read()
    sig, p = read_cstr(d,0)
    ver = struct.unpack_from('>I', d, p)[0]; p += 4
    uv, p = read_cstr(d,p); ur, p = read_cstr(d,p)
    size, cbi, ubi, flags = struct.unpack_from('>QIII', d, p); p += 20
    if ver >= 7: p = (p + 15) & ~15
    if flags & 0x80:
        bi = d[len(d)-cbi:]
    else:
        bi = d[p:p+cbi]; p += cbi
        if flags & 0x200: p = (p + 15) & ~15
    bi = decomp(bi, flags & 0x3f, ubi)
    q = 16
    nb = struct.unpack_from('>I', bi, q)[0]; q += 4
    blocks = []
    for _ in range(nb):
        u, c, f = struct.unpack_from('>IIH', bi, q); q += 10; blocks.append((u,c,f))
    nn = struct.unpack_from('>I', bi, q)[0]; q += 4
    nodes = []
    for _ in range(nn):
        off, sz, fl = struct.unpack_from('>QQI', bi, q); q += 20
        name, q = read_cstr(bi, q); nodes.append((off,sz,fl,name))
    out = b''
    for u,c,f in blocks:
        out += decomp(d[p:p+c], f & 0x3f, u); p += c
    files = {name: out[off:off+sz] for off,sz,fl,name in nodes}
    return uv, flags, blocks, nodes, files

if __name__ == '__main__':
    uv, flags, blocks, nodes, files = load(sys.argv[1])
    print(uv, hex(flags), blocks, [(n[3], n[1]) for n in nodes])
    for k,v in files.items():
        open('/home/claude/'+k.replace('/','_'),'wb').write(v)
