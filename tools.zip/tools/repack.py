import struct, json, sys
sys.path.insert(0,'/home/claude')
import ufs, sf, tables

SRC='/mnt/user-data/uploads/localization-string-tables-english_unitedstates__en-us__assets_all.bundle'

def build(pt, out_path):
    uv,flags,blocks,nodes,files=ufs.load(SRC)
    cab_name=nodes[0][3]; nflags=nodes[0][2]
    d=files[cab_name]
    m=sf.parse(d); base=m['data_off']
    # rebuild object data
    newdata=bytearray(); newobjs=[]
    for o in m['objs']:
        b=d[base+o['start']:base+o['start']+o['size']]
        if o['cid']==114 and b[28:32]!=b'':
            try:
                name,head,ents,tail=tables.parse_table(b)
            except Exception:
                name=None
            if name and name in pt:
                tr=pt[name]; assert len(tr)==len(ents),(name,len(tr),len(ents))
                ents=[(i,t) for (i,_),t in zip(ents,tr)]
                b=tables.build_table(head,ents,tail)
        while len(newdata)%16: newdata.append(0)
        newobjs.append((len(newdata),len(b)))
        newdata+=b
    # patch object table in metadata
    meta=bytearray(d[:base])
    # locate object table: re-walk
    r=sf.R(bytes(meta),m['hdr_end'],'<')
    r.cstr(); r.i32(); tt=r.u8(); nt=r.i32()
    for _ in range(nt):
        cid=r.i32(); r.u8(); r.u16()
        if cid==114: r.p+=16
        r.p+=16
        if tt:
            nn=r.i32(); sb=r.i32(); r.p+=nn*32+sb; dn=r.i32(); r.p+=dn*4
    oc=r.i32()
    for k in range(oc):
        r.align(); r.p+=8
        struct.pack_into('<q',meta,r.p,newobjs[k][0]); r.p+=8
        struct.pack_into('<I',meta,r.p,newobjs[k][1]); r.p+=4
        r.p+=4
    cab=bytes(meta)+bytes(newdata)
    # header fileSize (big-endian int64 at offset 20 of serialized header)
    cab=bytearray(cab); struct.pack_into('>q',cab,24,len(cab)); cab=bytes(cab)
    # bundle: uncompressed blocks
    BS=131072
    bl=[(min(BS,len(cab)-i),) for i in range(0,len(cab),BS)]
    bi=bytearray(b'\0'*16)+struct.pack('>I',len(bl))
    for (u,) in bl: bi+=struct.pack('>IIH',u,u,0)
    bi+=struct.pack('>I',1)+struct.pack('>QQI',0,len(cab),nflags)+cab_name.encode()+b'\0'
    hdr=b'UnityFS\0'+struct.pack('>I',8)+b'5.x.x\0'+uv.encode()+b'\0'
    # flags: no compression, blockinfo+dir combined (0x40), padding at start (0x200)
    f=0x240
    body_len=None
    pre=len(hdr)+8+4+4+4  # size,cbi,ubi,flags
    pad1=(-pre)%16
    pad2=(-(pre+pad1+len(bi)))%16
    total=pre+pad1+len(bi)+pad2+len(cab)
    out=hdr+struct.pack('>QIII',total,len(bi),len(bi),f)+b'\0'*pad1+bytes(bi)+b'\0'*pad2+cab
    open(out_path,'wb').write(out)
    return out_path

if __name__=='__main__':
    en=json.load(open('/home/claude/en.json'))
    pt={k:[s for _,s in v] for k,v in en.items()}
    build(pt,'/home/claude/test_identity.bundle')
