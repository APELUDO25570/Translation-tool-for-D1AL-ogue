import sys, json, re
sys.path.insert(0,'/home/claude/tr'); sys.path.insert(0,'/home/claude')
import title, tutorial, comment, commentdlg, cut1, cut2, news1, news2
en = json.load(open('/home/claude/en.json'))
SEP = re.compile(r'((?:\\n|\n| )*(?:\\n|\n)(?:\\n|\n| )*)')

def uniq_map(table, U):
    u=[]
    for _,s in en[table]:
        if s not in u: u.append(s)
    assert len(u)==len(U),(table,len(u),len(U))
    m=dict(zip(u,U))
    return [m[s] for _,s in en[table]]

def by_list(table, T):
    src=[s for _,s in en[table]]
    assert len(src)==len(T),(table,len(src),len(T))
    return [s if t is None else t for s,t in zip(src,T)]

def news(table, N):
    out=[]
    for k,(_,s) in enumerate(en[table]):
        parts=SEP.split(s)
        segs=parts[0::2]; seps=parts[1::2]
        tr=[x for x in N[k].split(' || ')]
        assert len(tr)==len(segs),(k,len(tr),len(segs))
        res=''
        for j,(sg,t) in enumerate(zip(segs,tr)):
            lead=sg[:len(sg)-len(sg.lstrip(' '))]; trail=sg[len(sg.rstrip(' ')):]
            res+=lead+t.strip(' ')+trail
            if j<len(seps): res+=seps[j]
        out.append(res)
    return out

pt={}
pt['TitleTables_en-US']=by_list('TitleTables_en-US',title.T)
pt['DialogueNameTable_en-US']=by_list('DialogueNameTable_en-US',title.NAMES)
pt['TutorialDialogueTable_en-US']=by_list('TutorialDialogueTable_en-US',tutorial.T)
pt['CommentTable_en-US']=uniq_map('CommentTable_en-US',comment.U)
pt['CommentDialogueTable_en-US']=uniq_map('CommentDialogueTable_en-US',commentdlg.U)
cs=cut1.T+cut2.T
cs=cs+cs[251:282]
pt['CutScene_en-US']=by_list('CutScene_en-US',cs)
N={**news1.N,**news2.N}
pt['NewsTable_en-US']=news('NewsTable_en-US',N)
# Dialogue: optional file
try:
    import dialogue_all
    pt['DialogueTable_en-US']=dialogue_all.get(en)
except ImportError:
    pt['DialogueTable_en-US']=[s for _,s in en['DialogueTable_en-US']]

# validation of markup
tok=re.compile(r'<[^>]+>|\{[0-9]+\}|\\n')
bad=0
for k in en:
    for n,((_,e),p) in enumerate(zip(en[k],pt[k])):
        te=sorted(tok.findall(e)); tp=sorted(tok.findall(p))
        if te!=tp:
            bad+=1; print('MISMATCH',k,n,te,tp)
        if e.count('\n')!=p.count('\n'): bad+=1; print('NL',k,n)
print('bad',bad)
json.dump(pt,open('/home/claude/pt.json','w'),ensure_ascii=False)
