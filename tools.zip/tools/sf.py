import struct
class R:
    def __init__(s,d,p=0,e='<'): s.d=d;s.p=p;s.e=e
    def u(s,f,n):
        v=struct.unpack_from(s.e+f,s.d,s.p)[0]; s.p+=n; return v
    def i32(s): return s.u('i',4)
    def u32(s): return s.u('I',4)
    def i64(s): return s.u('q',8)
    def u16(s): return s.u('H',2)
    def u8(s): return s.u('B',1)
    def cstr(s):
        e=s.d.index(b'\0',s.p); v=s.d[s.p:e].decode(); s.p=e+1; return v
    def align(s): s.p=(s.p+3)&~3

def parse(d):
    h=R(d,0,'>')
    h.u32();h.u32();ver=h.u32();h.u32()
    h.u8();h.p+=3
    meta_size=h.u32(); fsize=h.i64(); data_off=h.i64(); h.i64()
    r=R(d,h.p,'<')
    uv=r.cstr(); plat=r.i32(); tt=r.u8()
    nt=r.i32(); types=[]
    for _ in range(nt):
        cid=r.i32(); r.u8(); sti=r.u16()
        if cid==114: r.p+=16
        r.p+=16
        nodes=[]
        if tt:
            nn=r.i32(); sb=r.i32(); r.p+=nn*32+sb
            dn=r.i32(); r.p+=dn*4
        types.append(cid)
    oc=r.i32(); objs=[]
    for _ in range(oc):
        r.align(); pid=r.i64(); bs=r.i64(); sz=r.u32(); ti=r.i32()
        objs.append(dict(pid=pid,start=bs,size=sz,type=ti,cid=types[ti]))
    return dict(ver=ver,meta_size=meta_size,data_off=data_off,fsize=fsize,uv=uv,objs=objs,types=types,objtab_end=r.p,hdr_end=h.p)
if __name__=='__main__':
    import sys
    d=open(sys.argv[1],'rb').read()
    m=parse(d)
    print({k:v for k,v in m.items() if k!='objs'} )
    for o in m['objs']: print(o)
